
self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open('just-jump-v1').then(function(cache) {
      return cache.addAll(['./', './index.html', './icon.png', './splash.png', './manifest.json']);
    })
  );
});
self.addEventListener('fetch', function(e) {
  e.respondWith(caches.match(e.request).then(function(r) { return r || fetch(e.request); }));
});
